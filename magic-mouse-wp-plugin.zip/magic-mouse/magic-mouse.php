<?php
/*
Plugin Name: Magic Mouse Integration
Description: Integrates MagicMouse.js for desktop devices.
Version: 1.0
Author: Your Name
*/

function enqueue_magic_mouse() {
    if (wp_is_mobile()) {
        return;
    }
    wp_enqueue_script('magic-mouse-js', 'https://res.cloudinary.com/veseylab/raw/upload/v1684982764/magicmouse-2.0.0.cdn.min.js', array(), null, true);
    wp_enqueue_script('init-magic-mouse', plugins_url('/js/init-magic-mouse.js', __FILE__), array('magic-mouse-js'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_magic_mouse');
