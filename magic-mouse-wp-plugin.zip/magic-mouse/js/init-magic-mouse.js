document.addEventListener('DOMContentLoaded', function () {
    if (!/Mobi|Android/i.test(navigator.userAgent)) {
        var options = {
            cursorOuter: "circle",
            hoverEffect: "circle-move",
            hoverItemMove: false,
            defaultCursor: false,
            outerWidth: 30,
            outerHeight: 30
        };
        magicMouse(options);
    }
});
